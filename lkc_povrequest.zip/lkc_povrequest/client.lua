RegisterNetEvent('lkc_pov:notifyTarget', function(message)
    local pos   = (Config.Notify and Config.Notify.position) or 'top'
    local style = (Config.Notify and Config.Notify.style) or nil

    lib.notify({
        title       = 'POV',
        description = message or 'Player has requested pov post in Player report',
        type        = 'warning',
        position    = pos,
        duration    = 8000,
        style       = style
    })
end)
