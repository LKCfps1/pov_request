local lastGlobal, lastPair = {}, {}

local function nameOf(id) return GetPlayerName(id) or ('Unknown (%s)'):format(id) end

-- Everyone allowed; keep function for future flexibility
local function hasAccess(_source)
    -- If you ever want to lock again, read Config.RequiredAce here.
    return true
end

local function canSend(src, tgt)
    local now = os.time()
    if lastGlobal[src] and (now - lastGlobal[src]) < (Config.GlobalCooldown or 10) then
        return false, 'global'
    end
    lastPair[src] = lastPair[src] or {}
    if lastPair[src][tgt] and (now - lastPair[src][tgt]) < (Config.PairCooldown or 30) then
        return false, 'pair'
    end
    return true
end

local function markSend(src, tgt)
    local now = os.time()
    lastGlobal[src] = now
    lastPair[src] = lastPair[src] or {}
    lastPair[src][tgt] = now
end

local function sendWebhook(title, fields)
    if not Config.WebhookURL or Config.WebhookURL == '' then return end
    local embed = {
        title = title,
        color = Config.Embed.color_note or 0x5865F2,
        fields = fields,
        footer = { text = ('%s • %s'):format(Config.Embed.serverName or 'Server', os.date('%Y-%m-%d %H:%M:%S')) }
    }
    local payload = {
        username  = Config.Embed.username or 'POV Logger',
        avatar_url= Config.Embed.avatar_url,
        embeds    = { embed }
    }
    PerformHttpRequest(
        Config.WebhookURL,
        function() end,
        'POST',
        json.encode(payload),
        { ['Content-Type'] = 'application/json' }
    )
end

-- /pov [id]
RegisterCommand('pov', function(source, args)
    local src = source
    if src <= 0 then return end

    if not hasAccess(src) then
        lib.notify(src, { title = 'POV', description = 'No permission.', type = 'error' })
        return
    end

    local pos   = (Config.Notify and Config.Notify.position) or 'top'
    local style = (Config.Notify and Config.Notify.style) or nil

    local tgt = tonumber(args[1] or '0') or 0
    if tgt == 0 then
        lib.notify(src, { title = 'POV', description = Config.Text.usage, type = 'error', position = pos, style = style })
        return
    end
    if tgt == src then
        lib.notify(src, { title = 'POV', description = Config.Text.selfRequest, type = 'error', position = pos, style = style })
        return
    end
    if not GetPlayerName(tgt) then
        lib.notify(src, { title = 'POV', description = Config.Text.noPlayer, type = 'error', position = pos, style = style })
        return
    end

    local ok, block = canSend(src, tgt)
    if not ok then
        lib.notify(src, {
            title       = 'POV',
            description = (block == 'global' and Config.Text.blockedCooldown or Config.Text.blockedPair),
            type        = 'error',
            position    = pos,
            style       = style
        })
        return
    end

    markSend(src, tgt)

    -- Notify requester (bigger, centered)
    lib.notify(src, {
        title       = 'POV',
        description = Config.Text.sentToTarget:format(tgt),
        type        = 'success',
        position    = pos,
        duration    = 4000,
        style       = style
    })

    -- Notify target (bigger, centered)
    TriggerClientEvent('lkc_pov:notifyTarget', tgt, Config.Text.TargetPopup)

    -- Webhook log
    local srcName, tgtName = nameOf(src), nameOf(tgt)
    sendWebhook('POV Requested', {
        { name = 'Requester', value = ('%s (ID %s)'):format(srcName, src), inline = true },
        { name = 'Target',    value = ('%s (ID %s)'):format(tgtName, tgt), inline = true },
        { name = 'Message',   value = Config.Text.TargetPopup, inline = false },
    })
end, false)

-- Chat suggestion
AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    TriggerClientEvent('chat:addSuggestion', -1, '/pov', 'Send a POV request to a player (no accept/deny)', {
        { name = 'id', help = 'Target player ID' }
    })
end)
