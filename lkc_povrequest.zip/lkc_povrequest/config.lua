Config = {}

-- Cooldowns to prevent spam (seconds)
Config.GlobalCooldown = 10   -- requester cooldown between ANY requests
Config.PairCooldown   = 30   -- requester -> same target cooldown

-- Let ANYONE use /pov (leave nil or {})
Config.RequiredAce = nil

-- Discord webhook (logs every request)
Config.WebhookURL = 'https://discordapp.com/api/webhooks/postyourshere'

Config.Embed = {
    username   = 'POV Logger',
    avatar_url = nil,
    color_note = 0x5865F2,
    serverName = '4ESRP',
}

-- Bigger, centered notification style (target + requester)
Config.Notify = {
    position = 'top', -- 'top' = centered horizontally at top, 'bottom' = bottom-center
    style = {
        ['font-size']     = '22px',
        ['max-width']     = '720px',
        ['padding']       = '16px 20px',
        ['border-radius'] = '14px',
        -- Optional visual tweaks:
        -- ['background-color'] = 'rgba(0,0,0,0.92)',
        -- ['color']            = '#fff',
        -- ['box-shadow']       = '0 10px 30px rgba(0,0,0,0.35)',
        -- ['text-align']       = 'center',
    }
}

-- Texts
Config.Text = {
    usage           = 'Usage: /pov [server id]',
    selfRequest     = 'You cannot target yourself.',
    noPlayer        = 'Target ID not online.',
    sentToTarget    = 'POV request sent to ID %s.',
    blockedCooldown = 'Please wait before sending another POV request.',
    blockedPair     = 'You recently requested POV from this player. Try again later.',

    -- shown to target (exact phrase you asked for)
    TargetPopup     = 'Player has requested pov post in Player report',
}
